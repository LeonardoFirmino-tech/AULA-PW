const formulario = document.querySelector('#formLogin');
const mensagem = document.querySelector('#mensagem');

formulario.addEventListener('submit', async function(evento) {
  evento.preventDefault();

  const login = document.querySelector('#login').value;
  const senha = document.querySelector('#senha').value;

  try {
    const resposta = await fetch('http://localhost:3000/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ login: login, senha: senha })
    });

    const dados = await resposta.json();

    if (!resposta.ok) {
      mensagem.textContent = dados.erro || 'Usuario ou senha incorretos.';
      return;
    }

    localStorage.setItem('token', dados.token);
    localStorage.setItem('usuario', dados.usuario);
    window.location.href = 'index.html';
  } catch (erro) {
    mensagem.textContent = 'Nao foi possivel conectar ao servidor.';
  }
});
