@echo off
cd /d "%~dp0"
title Sistema de Funcionarios

echo Iniciando o sistema...

where node >nul 2>nul
if errorlevel 1 (
  echo Instale o Node.js antes de continuar.
  pause
  exit /b
)

if not exist node_modules (
  echo Instalando os arquivos necessarios...
  call npm install
  if errorlevel 1 goto erro
)

echo.
echo Preparando o banco de dados...
call npm run preparar-banco
if errorlevel 1 goto erro

echo.
echo Abrindo a pagina de login...
start "" "%~dp0login.html"
echo.
echo O sistema esta funcionando na porta 3000.
echo Login: admin
 echo Senha: 1234
 echo Para fechar, pressione Ctrl+C.
echo.
call npm start
pause
exit /b

:erro
echo Ocorreu um erro. Confira se o MySQL do XAMPP esta ligado.
pause
