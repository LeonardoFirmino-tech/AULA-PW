APINODEJS — projeto baseado no PDF

Requisitos: Node.js e MongoDB Community instalados.

1. Extraia a pasta.
2. Abra o terminal dentro da pasta APINODEJS.
3. Execute: npm install
4. Inicie o serviço do MongoDB Community.
5. Execute: npm start
6. Acesse http://localhost:3000 no navegador.

A página HTML permite cadastrar uma pessoa e enviar os dados para a API, que os grava no MongoDB.
