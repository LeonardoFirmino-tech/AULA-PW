require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Conexao com o banco de dados
const banco = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'crud_funcionarios'
});

const chave = process.env.JWT_SECRET || 'chave-do-projeto';

// Fazer login
app.post('/api/login', async (req, res) => {
  try {
    const { login, senha } = req.body;
    const [usuarios] = await banco.execute(
      'SELECT * FROM usuarios WHERE login = ?', [login]
    );

    if (usuarios.length === 0) {
      return res.status(401).json({ erro: 'Usuario ou senha incorretos.' });
    }

    const usuario = usuarios[0];
    const senhaCerta = await bcrypt.compare(senha, usuario.senha);

    if (!senhaCerta) {
      return res.status(401).json({ erro: 'Usuario ou senha incorretos.' });
    }

    const token = jwt.sign({ id: usuario.id }, chave, { expiresIn: '8h' });
    res.json({ token: token, usuario: usuario.login });
  } catch (erro) {
    res.status(500).json({ erro: 'Erro ao fazer login.' });
  }
});

// Verificar se a pessoa fez login
function verificarLogin(req, res, next) {
  const token = req.headers.authorization;

  if (!token) {
    return res.status(401).json({ erro: 'Faça login primeiro.' });
  }

  try {
    jwt.verify(token.replace('Bearer ', ''), chave);
    next();
  } catch (erro) {
    res.status(401).json({ erro: 'Login expirado.' });
  }
}

// Rotas dos funcionarios
app.get('/api/funcionarios', verificarLogin, async (req, res) => {
  try {
    const [funcionarios] = await banco.execute('SELECT * FROM funcionarios');
    res.json(funcionarios);
  } catch (erro) {
    res.status(500).json({ erro: 'Erro ao buscar funcionarios.' });
  }
});

app.post('/api/funcionarios', verificarLogin, async (req, res) => {
  try {
    const { nome, funcao, salario } = req.body;
    await banco.execute(
      'INSERT INTO funcionarios (nome, funcao, salario) VALUES (?, ?, ?)',
      [nome, funcao, salario]
    );
    res.json({ mensagem: 'Funcionario cadastrado!' });
  } catch (erro) {
    res.status(500).json({ erro: 'Erro ao cadastrar funcionario.' });
  }
});

app.put('/api/funcionarios/:id', verificarLogin, async (req, res) => {
  try {
    const { nome, funcao, salario } = req.body;
    await banco.execute(
      'UPDATE funcionarios SET nome = ?, funcao = ?, salario = ? WHERE id = ?',
      [nome, funcao, salario, req.params.id]
    );
    res.json({ mensagem: 'Funcionario atualizado!' });
  } catch (erro) {
    res.status(500).json({ erro: 'Erro ao atualizar funcionario.' });
  }
});

app.delete('/api/funcionarios/:id', verificarLogin, async (req, res) => {
  try {
    await banco.execute('DELETE FROM funcionarios WHERE id = ?', [req.params.id]);
    res.json({ mensagem: 'Funcionario excluido!' });
  } catch (erro) {
    res.status(500).json({ erro: 'Erro ao excluir funcionario.' });
  }
});

app.listen(3000, () => {
  console.log('Servidor iniciado em http://localhost:3000');
});
