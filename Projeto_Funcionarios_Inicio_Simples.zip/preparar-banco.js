require('dotenv').config();
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');

async function main() {
  const config = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || ''
  };
  const db = await mysql.createConnection(config);
  await db.query('CREATE DATABASE IF NOT EXISTS crud_funcionarios CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
  await db.query('USE crud_funcionarios');
  await db.query(`CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL
  )`);
  await db.query(`CREATE TABLE IF NOT EXISTS funcionarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    funcao VARCHAR(100) NOT NULL,
    salario DECIMAL(10,2) NOT NULL
  )`);
  const hash = await bcrypt.hash('Admin123!', 12);
  await db.execute('INSERT INTO usuarios (login, senha) VALUES (?, ?) ON DUPLICATE KEY UPDATE senha = VALUES(senha)', ['admin', hash]);
  await db.end();
  console.log('\nBanco e tabelas preparados. Login inicial: admin | Senha: Admin123!\n');
}
main().catch(e => { console.error('\nERRO ao preparar banco:', e.message); console.error('Confira se o MySQL do XAMPP está iniciado e se usuário/senha estão corretos.'); process.exit(1); });
