const form = document.querySelector('#formLogin')
const campoUsuario = document.querySelector('#usuario')
const campoSenha = document.querySelector('#senha')
const mensagem = document.querySelector('#mensagem')

// usuário e senha fixos apenas para exemplo
const usuarioCorreto = 'admin'
const senhaCorreta = '1234'

form.onsubmit = e => {
    e.preventDefault()

    const usuario = campoUsuario.value
    const senha = campoSenha.value

    if (usuario === usuarioCorreto && senha === senhaCorreta) {
        mensagem.style.color = 'green'
        mensagem.textContent = 'Login realizado com sucesso!'

        setTimeout(() => {
            window.location.href = 'index.html'
        }, 1000)
    } else {
        mensagem.style.color = 'red'
        mensagem.textContent = 'Usuário ou senha incorretos.'
    }
}
