require('dotenv').config();
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');

async function prepararBanco() {
  const banco = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || ''
  });

  await banco.query('CREATE DATABASE IF NOT EXISTS crud_funcionarios');
  await banco.query('USE crud_funcionarios');

  await banco.query(`CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL
  )`);

  await banco.query(`CREATE TABLE IF NOT EXISTS funcionarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    funcao VARCHAR(100) NOT NULL,
    salario DECIMAL(10,2) NOT NULL
  )`);

  const [usuarios] = await banco.execute('SELECT * FROM usuarios WHERE login = ?', ['admin']);
  if (usuarios.length === 0) {
    const senha = await bcrypt.hash('1234', 10);
    await banco.execute('INSERT INTO usuarios (login, senha) VALUES (?, ?)', ['admin', senha]);
  }

  await banco.end();
  console.log('Banco de dados pronto!');
  console.log('Login: admin | Senha: 1234');
}

prepararBanco().catch(function(erro) {
  console.log('Erro ao preparar o banco:', erro.message);
  process.exit(1);
});
