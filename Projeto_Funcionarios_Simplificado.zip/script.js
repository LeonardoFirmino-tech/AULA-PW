const endereco = 'http://localhost:3000/api/funcionarios';
const tabela = document.querySelector('tbody');
const modal = document.querySelector('.modal-container');

let funcionarios = [];
let idAtual = null;

// Pega o token salvo quando o usuario fez login
function pegarToken() {
  return {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + localStorage.getItem('token')
  };
}

// Mostra os funcionarios na tabela
async function carregarFuncionarios() {
  try {
    const resposta = await fetch(endereco, { headers: pegarToken() });

    if (resposta.status === 401) {
      localStorage.removeItem('token');
      window.location.href = 'login.html';
      return;
    }

    funcionarios = await resposta.json();
    tabela.innerHTML = '';

    funcionarios.forEach(function(funcionario, indice) {
      const linha = document.createElement('tr');
      linha.innerHTML = `
        <td>${funcionario.nome}</td>
        <td>${funcionario.funcao}</td>
        <td>R$ ${Number(funcionario.salario).toFixed(2)}</td>
        <td><button onclick="editarFuncionario(${indice})">Editar</button></td>
        <td><button onclick="excluirFuncionario(${funcionario.id})">Excluir</button></td>
      `;
      tabela.appendChild(linha);
    });
  } catch (erro) {
    alert('Erro ao carregar os funcionarios. Veja se o servidor esta ligado.');
  }
}

// Abre o formulario
function openModal() {
  idAtual = null;
  document.querySelector('#m-nome').value = '';
  document.querySelector('#m-funcao').value = '';
  document.querySelector('#m-salario').value = '';
  modal.classList.add('active');
}

// Coloca os dados no formulario para editar
function editarFuncionario(indice) {
  const funcionario = funcionarios[indice];
  idAtual = funcionario.id;
  document.querySelector('#m-nome').value = funcionario.nome;
  document.querySelector('#m-funcao').value = funcionario.funcao;
  document.querySelector('#m-salario').value = funcionario.salario;
  modal.classList.add('active');
}

// Salva um funcionario novo ou alterado
document.querySelector('#btnSalvar').addEventListener('click', async function(evento) {
  evento.preventDefault();

  const nome = document.querySelector('#m-nome').value;
  const funcao = document.querySelector('#m-funcao').value;
  const salario = document.querySelector('#m-salario').value;

  if (nome === '' || funcao === '' || salario === '') {
    alert('Preencha todos os campos.');
    return;
  }

  const dados = { nome: nome, funcao: funcao, salario: salario };
  let resposta;

  if (idAtual === null) {
    resposta = await fetch(endereco, {
      method: 'POST', headers: pegarToken(), body: JSON.stringify(dados)
    });
  } else {
    resposta = await fetch(endereco + '/' + idAtual, {
      method: 'PUT', headers: pegarToken(), body: JSON.stringify(dados)
    });
  }

  if (resposta.ok) {
    modal.classList.remove('active');
    carregarFuncionarios();
  } else {
    alert('Nao foi possivel salvar.');
  }
});

// Exclui um funcionario
async function excluirFuncionario(id) {
  if (confirm('Deseja excluir este funcionario?')) {
    const resposta = await fetch(endereco + '/' + id, {
      method: 'DELETE', headers: pegarToken()
    });

    if (resposta.ok) carregarFuncionarios();
    else alert('Nao foi possivel excluir.');
  }
}

// Fecha o formulario quando clicar fora dele
modal.addEventListener('click', function(evento) {
  if (evento.target === modal) modal.classList.remove('active');
});

carregarFuncionarios();
