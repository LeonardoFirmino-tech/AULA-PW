PROJETO APINODEJS — baseado no PDF fornecido

Requisitos:
- Node.js instalado.
- MongoDB Community instalado e em execução.

Como executar:
1. Abra esta pasta no VS Code.
2. No terminal, execute: npm install
3. Execute: npm start
4. Teste no navegador ou PowerShell: http://localhost:3000/

A rota inicial GET / retorna:
{"message":"Oi Express"}

Para inserir uma pessoa, envie uma requisição POST para //person com JSON:
{
  "name": "João",
  "salary": 2500,
  "approved": true
}

O banco local utilizado é apinodejs, no endereço:
mongodb://127.0.0.1:27017/apinodejs

Observação fiel ao PDF:
- O PDF mostra a rota POST como '//person'; por isso, ela foi mantida assim.
- O PDF usa o modelo Person, mas não apresenta sua definição nem a conexão completa com o banco. O arquivo models/Person.js e a conexão foram incluídos apenas para permitir que o exemplo de inserção funcione.
- O PDF instala o pacote como "mongose" em uma linha, mas o nome correto do pacote usado no próprio package.json é "mongoose".
