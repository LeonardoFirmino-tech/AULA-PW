﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Sistema de Funcionarios - Inicializacao
echo ============================================
echo   SISTEMA DE FUNCIONARIOS COM LOGIN
echo ============================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo ERRO: Node.js nao esta instalado.
  echo Instale a versao LTS em https://nodejs.org/ e abra este arquivo novamente.
  pause
  exit /b 1
)
echo [1/3] Instalando dependencias...
call npm install
if errorlevel 1 goto erro
echo.
echo [2/3] Preparando banco e usuario inicial...
node preparar-banco.js
if errorlevel 1 goto erro
echo.
echo [3/3] Iniciando servidor...
echo Quando aparecer Servidor rodando, abra login.html nesta pasta.
echo Login: admin    Senha: Admin123!
echo Para encerrar, feche esta janela ou pressione Ctrl+C.
echo.
call npm start
pause
exit /b 0
:erro
echo.
echo Nao foi possivel iniciar. Confira as mensagens acima.
pause
exit /b 1
