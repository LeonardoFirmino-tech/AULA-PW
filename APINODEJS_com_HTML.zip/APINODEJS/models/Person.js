const mongoose = require('mongoose');

const personSchema = new mongoose.Schema({
  name: String,
  salary: Number,
  approved: Boolean
});

module.exports = mongoose.model('Person', personSchema);