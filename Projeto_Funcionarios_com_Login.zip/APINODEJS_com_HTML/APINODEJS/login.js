const API_LOGIN = 'http://localhost:3000/api/login';
const formLogin = document.querySelector('#formLogin');
const mensagem = document.querySelector('#mensagem');

if (localStorage.getItem('token')) window.location.replace('index.html');

formLogin.addEventListener('submit', async (event) => {
  event.preventDefault();
  mensagem.textContent = '';
  const login = document.querySelector('#login').value.trim();
  const senha = document.querySelector('#senha').value;

  try {
    const response = await fetch(API_LOGIN, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ login, senha })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Não foi possível entrar.');
    localStorage.setItem('token', data.token);
    localStorage.setItem('usuario', data.usuario.login);
    window.location.replace('index.html');
  } catch (error) {
    mensagem.textContent = error.message === 'Failed to fetch'
      ? 'Não foi possível conectar ao servidor. Verifique se o Node.js está iniciado.'
      : error.message;
  }
});
