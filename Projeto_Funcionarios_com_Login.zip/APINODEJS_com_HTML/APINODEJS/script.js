const API_BASE = 'http://localhost:3000/api/funcionarios';
const modal = document.querySelector('.modal-container');
const tbody = document.querySelector('tbody');
const sNome = document.querySelector('#m-nome');
const sFuncao = document.querySelector('#m-funcao');
const sSalario = document.querySelector('#m-salario');
const btnSalvar = document.querySelector('#btnSalvar');
let itens = [];
let idEdicao;

function headersAutenticados(json = false) {
  const headers = { Authorization: `Bearer ${localStorage.getItem('token') || ''}` };
  if (json) headers['Content-Type'] = 'application/json';
  return headers;
}

async function tratarResposta(response) {
  if (response.status === 401) {
    localStorage.removeItem('token');
    localStorage.removeItem('usuario');
    window.location.replace('login.html');
    throw new Error('Sessão expirada. Entre novamente.');
  }
  if (!response.ok) {
    const erro = await response.json().catch(() => ({}));
    throw new Error(erro.error || 'Ocorreu um erro na solicitação.');
  }
  return response.status === 204 ? null : response.json();
}

function openModal(edit = false, index = 0) {
  modal.classList.add('active');
  modal.onclick = event => {
    if (event.target === modal) modal.classList.remove('active');
  };
  if (edit) {
    const item = itens[index];
    sNome.value = item.nome;
    sFuncao.value = item.funcao;
    sSalario.value = item.salario;
    idEdicao = item.id;
  } else {
    sNome.value = '';
    sFuncao.value = '';
    sSalario.value = '';
    idEdicao = undefined;
  }
}

function editItem(index) { openModal(true, index); }

async function deleteItem(index) {
  if (!itens[index]?.id || !confirm(`Excluir ${itens[index].nome}?`)) return;
  try {
    const response = await fetch(`${API_BASE}/${itens[index].id}`, {
      method: 'DELETE', headers: headersAutenticados()
    });
    await tratarResposta(response);
    await loadItens();
  } catch (error) { alert(error.message); }
}

function insertItem(item, index) {
  const tr = document.createElement('tr');
  const nome = document.createElement('td'); nome.textContent = item.nome;
  const funcao = document.createElement('td'); funcao.textContent = item.funcao;
  const salario = document.createElement('td'); salario.textContent = `R$ ${Number(item.salario).toFixed(2)}`;
  const editar = document.createElement('td'); editar.className = 'acao';
  const btnEditar = document.createElement('button'); btnEditar.type = 'button'; btnEditar.innerHTML = "<i class='bx bx-edit'></i>";
  btnEditar.addEventListener('click', () => editItem(index)); editar.appendChild(btnEditar);
  const excluir = document.createElement('td'); excluir.className = 'acao';
  const btnExcluir = document.createElement('button'); btnExcluir.type = 'button'; btnExcluir.innerHTML = "<i class='bx bx-trash'></i>";
  btnExcluir.addEventListener('click', () => deleteItem(index)); excluir.appendChild(btnExcluir);
  tr.append(nome, funcao, salario, editar, excluir); tbody.appendChild(tr);
}

btnSalvar.addEventListener('click', async event => {
  event.preventDefault();
  if (!sNome.value.trim() || !sFuncao.value.trim() || sSalario.value === '') return;
  const dados = { nome: sNome.value.trim(), funcao: sFuncao.value.trim(), salario: sSalario.value };
  try {
    const response = await fetch(idEdicao ? `${API_BASE}/${idEdicao}` : API_BASE, {
      method: idEdicao ? 'PUT' : 'POST',
      headers: headersAutenticados(true),
      body: JSON.stringify(dados)
    });
    await tratarResposta(response);
    modal.classList.remove('active');
    idEdicao = undefined;
    await loadItens();
  } catch (error) { alert(error.message); }
});

async function loadItens() {
  try {
    const response = await fetch(API_BASE, { headers: headersAutenticados() });
    itens = await tratarResposta(response);
    tbody.innerHTML = '';
    itens.forEach(insertItem);
  } catch (error) {
    if (error.message !== 'Sessão expirada. Entre novamente.') console.error(error);
  }
}

loadItens();
