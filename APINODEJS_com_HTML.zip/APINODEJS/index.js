const express = require('express');
const mongoose = require('mongoose');
const Person = require('./models/Person');

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));

mongoose.connect('mongodb://127.0.0.1:27017/apinodejs')
  .then(() => {
    app.get('/', (req, res) => {
      res.sendFile(__dirname + '/public/index.html');
    });

    app.post('//person', async (req, res) => {
      const { name, salary, approved } = req.body;
      const person = { name, salary, approved };

      try {
        await Person.create(person);
        res.status(201).json({ message: 'Pessoa inserida no sistema com sucesso!' });
      } catch (error) {
        res.status(500).json({ erro: error.message });
      }
    });

    app.listen(3000, () => console.log('Servidor rodando em http://localhost:3000'));
  })
  .catch((error) => {
    console.error('Erro ao conectar ao MongoDB:', error.message);
    process.exit(1);
  });