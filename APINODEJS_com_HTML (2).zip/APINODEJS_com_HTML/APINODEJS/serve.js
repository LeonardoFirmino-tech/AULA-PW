
const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

// Configuração do banco de dados
const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'crud_funcionarios'
};

const db = mysql.createPool(dbConfig);

// GET /api/funcionarios
// Listar todos os funcionários
app.get('/api/funcionarios', async (req, res) => {
    try {
        const [rows] = await db.execute(
            'SELECT * FROM funcionarios ORDER BY id DESC'
        );

        res.json(rows);

    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// POST /api/funcionarios
// Cadastrar funcionário
app.post('/api/funcionarios', async (req, res) => {
    try {
        const { nome, funcao, salario } = req.body;

        if (!nome || !funcao || salario === undefined || salario === null || salario === '') {
            return res.status(400).json({
                error: 'Campos obrigatórios'
            });
        }

        const [result] = await db.execute(
            'INSERT INTO funcionarios (nome, funcao, salario) VALUES (?, ?, ?)',
            [nome, funcao, parseFloat(salario)]
        );

        res.status(201).json({
            success: true,
            id: result.insertId
        });

    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// PUT /api/funcionarios/:id
// Atualizar funcionário
app.put('/api/funcionarios/:id', async (req, res) => {
    try {
        const { nome, funcao, salario } = req.body;
        const id = req.params.id;

        if (!nome || !funcao || salario === undefined || salario === null || salario === '') {
            return res.status(400).json({
                error: 'Todos os campos são obrigatórios'
            });
        }

        const salarioNumerico = parseFloat(salario);

        if (!Number.isFinite(salarioNumerico)) {
            return res.status(400).json({
                error: 'Salário inválido'
            });
        }

        await db.execute(
            'UPDATE funcionarios SET nome = ?, funcao = ?, salario = ? WHERE id = ?',
            [nome, funcao, salarioNumerico, id]
        );

        res.json({ success: true });

    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// DELETE /api/funcionarios/:id
// Excluir funcionário
app.delete('/api/funcionarios/:id', async (req, res) => {
    try {
        const id = req.params.id;

        await db.execute(
            'DELETE FROM funcionarios WHERE id = ?',
            [id]
        );

        res.json({ success: true });

    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Iniciar servidor
const PORT = 3000;

app.listen(PORT, () => {
    console.log(`🚀 Servidor rodando em http://localhost:${5500}`);
    console.log('Endpoints: /api/funcionarios');
    console.log('GET / POST / PUT/:id / DELETE/:id');
});
