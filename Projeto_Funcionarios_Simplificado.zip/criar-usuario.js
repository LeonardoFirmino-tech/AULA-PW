require('dotenv').config();
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');

async function main() {
  const login = process.argv[2] || 'admin';
  const senha = process.argv[3] || 'Admin123!';
  const db = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'crud_funcionarios'
  });
  const hash = await bcrypt.hash(senha, 12);
  await db.execute(
    'INSERT INTO usuarios (login, senha) VALUES (?, ?) ON DUPLICATE KEY UPDATE senha = VALUES(senha)',
    [login, hash]
  );
  console.log(`Usuário "${login}" criado/atualizado com sucesso.`);
  await db.end();
}

main().catch(error => { console.error('Não foi possível criar o usuário:', error.message); process.exit(1); });
