const API_BASE = 'http://localhost:3000/api/funcionarios';

const modal = document.querySelector('.modal-container');
const tbody = document.querySelector('tbody');
const sNome = document.querySelector('#m-nome');
const sFuncao = document.querySelector('#m-funcao');
const sSalario = document.querySelector('#m-salario');
const btnSalvar = document.querySelector('#btnSalvar');

let itens = [];
let id;

function openModal(edit = false, index = 0) {
    modal.classList.add('active');

    modal.onclick = e => {
        if (e.target === modal) {
            modal.classList.remove('active');
        }
    };

    if (edit) {
        sNome.value = itens[index].nome;
        sFuncao.value = itens[index].funcao;
        sSalario.value = itens[index].salario;
        id = index;
    } else {
        sNome.value = '';
        sFuncao.value = '';
        sSalario.value = '';
        id = undefined;
    }
}

function editItem(index) {
    openModal(true, index);
}

async function deleteItem(index) {
    if (!itens[index]?.id) return;

    try {
        const response = await fetch(`${API_BASE}/${itens[index].id}`, {
            method: 'DELETE'
        });

        if (!response.ok) throw new Error('Não foi possível excluir o funcionário.');

        await loadItens();
    } catch (error) {
        console.error('Erro ao deletar:', error);
        alert('Erro ao excluir funcionário.');
    }
}

function insertItem(item, index) {
    const tr = document.createElement('tr');

    tr.innerHTML = `
        <td>${item.nome}</td>
        <td>${item.funcao}</td>
        <td>R$ ${Number(item.salario).toFixed(2)}</td>
        <td class="acao">
            <button type="button" onclick="editItem(${index})">
                <i class="bx bx-edit"></i>
            </button>
        </td>
        <td class="acao">
            <button type="button" onclick="deleteItem(${index})">
                <i class="bx bx-trash"></i>
            </button>
        </td>
    `;

    tbody.appendChild(tr);
}

btnSalvar.onclick = async e => {
    e.preventDefault();

    if (
        sNome.value.trim() === '' ||
        sFuncao.value.trim() === '' ||
        sSalario.value === ''
    ) {
        return;
    }

    const funcionario = {
        nome: sNome.value.trim(),
        funcao: sFuncao.value.trim(),
        salario: Number(sSalario.value)
    };

    try {
        let response;

        if (id !== undefined && itens[id]?.id) {
            response = await fetch(`${API_BASE}/${itens[id].id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(funcionario)
            });
        } else {
            response = await fetch(API_BASE, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(funcionario)
            });
        }

        if (!response.ok) throw new Error('Não foi possível salvar o funcionário.');

        modal.classList.remove('active');
        id = undefined;
        await loadItens();
    } catch (error) {
        console.error('Erro ao salvar:', error);
        alert('Erro ao salvar. Verifique se o servidor está rodando.');
    }
};

async function loadItens() {
    itens = await getItensBD();
    tbody.innerHTML = '';

    itens.forEach((item, index) => {
        insertItem(item, index);
    });
}

async function getItensBD() {
    try {
        const response = await fetch(API_BASE);

        if (!response.ok) throw new Error('Erro ao carregar funcionários.');

        return await response.json();
    } catch (error) {
        console.error('Erro API:', error);
        return [];
    }
}

loadItens();
