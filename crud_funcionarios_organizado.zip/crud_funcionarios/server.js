const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'crud_funcionarios'
};

const db = mysql.createPool(dbConfig);

app.get('/api/funcionarios', async (req, res) => {
    try {
        const [rows] = await db.execute(
            'SELECT * FROM funcionarios ORDER BY id DESC'
        );

        res.json(rows);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/funcionarios', async (req, res) => {
    try {
        const { nome, funcao, salario } = req.body;

        if (!nome || !funcao || salario === undefined || salario === '') {
            return res.status(400).json({ error: 'Campos obrigatórios.' });
        }

        const [result] = await db.execute(
            'INSERT INTO funcionarios (nome, funcao, salario) VALUES (?, ?, ?)',
            [nome, funcao, parseFloat(salario)]
        );

        res.status(201).json({ success: true, id: result.insertId });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.put('/api/funcionarios/:id', async (req, res) => {
    try {
        const { nome, funcao, salario } = req.body;
        const id = req.params.id;

        if (!nome || !funcao || salario === undefined || salario === '') {
            return res.status(400).json({ error: 'Campos obrigatórios.' });
        }

        const [result] = await db.execute(
            'UPDATE funcionarios SET nome = ?, funcao = ?, salario = ? WHERE id = ?',
            [nome, funcao, parseFloat(salario), id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Funcionário não encontrado.' });
        }

        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.delete('/api/funcionarios/:id', async (req, res) => {
    try {
        const id = req.params.id;
        const [result] = await db.execute(
            'DELETE FROM funcionarios WHERE id = ?',
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Funcionário não encontrado.' });
        }

        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

const PORT = 3000;

app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
    console.log('Endpoint: /api/funcionarios (GET, POST, PUT/:id, DELETE/:id)');
});
