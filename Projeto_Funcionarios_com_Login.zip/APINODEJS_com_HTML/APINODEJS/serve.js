require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors());
app.use(express.json());

const db = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'crud_funcionarios',
  waitForConnections: true,
  connectionLimit: 10
});

const JWT_SECRET = process.env.JWT_SECRET || 'troque-esta-chave-antes-de-publicar-o-projeto';

app.post('/api/login', async (req, res) => {
  try {
    const { login, senha } = req.body;
    if (!login || !senha) return res.status(400).json({ error: 'Informe login e senha.' });

    const [usuarios] = await db.execute(
      'SELECT id, login, senha FROM usuarios WHERE login = ? LIMIT 1', [login]
    );
    if (!usuarios.length) return res.status(401).json({ error: 'Login ou senha incorretos.' });

    const usuario = usuarios[0];
    const senhaValida = await bcrypt.compare(senha, usuario.senha);
    if (!senhaValida) return res.status(401).json({ error: 'Login ou senha incorretos.' });

    const token = jwt.sign({ id: usuario.id, login: usuario.login }, JWT_SECRET, { expiresIn: '8h' });
    res.json({ success: true, token, usuario: { id: usuario.id, login: usuario.login } });
  } catch (error) {
    console.error('Erro no login:', error);
    res.status(500).json({ error: 'Erro interno ao realizar login.' });
  }
});

function autenticar(req, res, next) {
  const cabecalho = req.headers.authorization || '';
  const token = cabecalho.startsWith('Bearer ') ? cabecalho.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Acesso não autorizado. Faça login.' });
  try {
    req.usuario = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: 'Sessão inválida ou expirada. Faça login novamente.' });
  }
}

// Todas as rotas do CRUD exigem autenticação.
app.use('/api/funcionarios', autenticar);

app.get('/api/funcionarios', async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT * FROM funcionarios ORDER BY id DESC');
    res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao listar funcionários.' });
  }
});

app.post('/api/funcionarios', async (req, res) => {
  try {
    const { nome, funcao, salario } = req.body;
    const salarioNumerico = Number(salario);
    if (!nome || !funcao || salario === '' || !Number.isFinite(salarioNumerico)) {
      return res.status(400).json({ error: 'Informe nome, função e salário válido.' });
    }
    const [result] = await db.execute(
      'INSERT INTO funcionarios (nome, funcao, salario) VALUES (?, ?, ?)',
      [nome, funcao, salarioNumerico]
    );
    res.status(201).json({ success: true, id: result.insertId });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao cadastrar funcionário.' });
  }
});

app.put('/api/funcionarios/:id', async (req, res) => {
  try {
    const { nome, funcao, salario } = req.body;
    const salarioNumerico = Number(salario);
    if (!nome || !funcao || salario === '' || !Number.isFinite(salarioNumerico)) {
      return res.status(400).json({ error: 'Informe nome, função e salário válido.' });
    }
    const [result] = await db.execute(
      'UPDATE funcionarios SET nome = ?, funcao = ?, salario = ? WHERE id = ?',
      [nome, funcao, salarioNumerico, req.params.id]
    );
    if (!result.affectedRows) return res.status(404).json({ error: 'Funcionário não encontrado.' });
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao atualizar funcionário.' });
  }
});

app.delete('/api/funcionarios/:id', async (req, res) => {
  try {
    const [result] = await db.execute('DELETE FROM funcionarios WHERE id = ?', [req.params.id]);
    if (!result.affectedRows) return res.status(404).json({ error: 'Funcionário não encontrado.' });
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao excluir funcionário.' });
  }
});

const PORT = Number(process.env.PORT) || 3000;
app.listen(PORT, () => console.log(`Servidor rodando em http://localhost:${PORT}`));
